# FlowerShopManagement
This is  a flower shop where user can buy the flowers they wish to buy.  The system makes the flower sales management work standardized, systematic and procedural,  improves the speed and accuracy of sales.
